from .str_utils import *

count_occurrences = many_count

__all__ = ['count_occurrences', 'many_count']
