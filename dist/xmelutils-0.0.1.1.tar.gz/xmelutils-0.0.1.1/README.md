# Igor's Utilities
I made these tools for myself, but you're welcome to use them if they're helpful.


## Download
```bash
pip install xmelutils
```